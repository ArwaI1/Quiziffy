using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages;

public class LeaderboardModel : PageModel
{
    public void OnGet()
    {
    }
}