using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages;

public class AuthorFeedbackModel : PageModel
{
    public void OnGet()
    {
    }
}