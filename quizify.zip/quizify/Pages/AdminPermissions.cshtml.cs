using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages;

public class AdminPermissionsModel : PageModel
{
    public void OnGet()
    {
    }
}