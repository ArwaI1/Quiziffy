using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages;

public class AdminRoomModel : PageModel
{
    public void OnGet()
    {
    }
}