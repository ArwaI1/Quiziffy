using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages;

public class AuthorHomePageModel : PageModel
{
    public void OnGet()
    {
    }
}